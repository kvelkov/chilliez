#[cfg(test)]
mod tests {
    #[test]
    fn smoke_test() {
        // Basic test to verify test harness is working
        assert_eq!(2 + 2, 4);
    }
}
