pub mod client;
pub mod strategy;

pub async fn start() {
    println!("🚀 Starting Rust bot...");

    // TODO: Add your strategy loop, API calls, etc.
}
