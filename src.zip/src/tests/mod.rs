pub mod detector_test;
pub mod integration_test;
pub mod pool_discovery_test; // Add pool discovery integration test